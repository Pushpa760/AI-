from flask import Flask, render_template, request

app = Flask(__name__)

# ---------------- KNOWLEDGE BASE ---------------- #

vehicle_rules = {

    "Engine Noise": {
        "cause": "Loose Engine Belt",
        "solution": "Tighten or replace the engine belt."
    },

    "Low Mileage": {
        "cause": "Dirty Air Filter",
        "solution": "Clean or replace air filter."
    },

    "Brake Issue": {
        "cause": "Worn Brake Pads",
        "solution": "Replace brake pads immediately."
    },

    "Smoke from Exhaust": {
        "cause": "Engine Oil Leakage",
        "solution": "Repair oil leakage."
    },

    "Battery Not Charging": {
        "cause": "Faulty Alternator",
        "solution": "Repair or replace alternator."
    },

    "Car Not Starting": {
        "cause": "Dead Battery",
        "solution": "Recharge or replace battery."
    }
}

# ---------------- HOME PAGE ---------------- #

@app.route("/")

def home():
    return render_template("home.html")

# ---------------- DETECTION PAGE ---------------- #

@app.route("/detect")

def detect():
    return render_template(
        "detect.html",
        symptoms=vehicle_rules.keys()
    )

# ---------------- RESULT PAGE ---------------- #

@app.route("/result", methods=["POST"])

def result():

    symptom = request.form["symptom"]

    result = vehicle_rules.get(symptom)

    return render_template(
        "result.html",
        symptom=symptom,
        result=result
    )

# ---------------- RUN ---------------- #

if __name__ == "__main__":
    app.run(debug=True)